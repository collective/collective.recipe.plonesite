Introduction
============

This recipe enables you to create and update a Plone site as part of a
buildout run. This recipe only aims to run profiles and Quickinstall
products. It is assumed that the install methods, setuphandlers, upgrade
steps, and other recipes will handle the rest of the work.

.. contents::

- Code repository: http://svn.plone.org/svn/collective/buildout/collective.recipe.plonesite
- Report bugs at https://bugs.launchpad.net/collective.buildout/
